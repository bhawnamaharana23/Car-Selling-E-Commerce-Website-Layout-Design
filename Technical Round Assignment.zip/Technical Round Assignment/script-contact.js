const row = document.querySelector('.row'),
	  form = row.querySelectorAll('.form'),
	  submitInput = form[0].querySelector('input[type="submit"]');

function getDataform(e) {
	e.preventDefault();

	var formData = new FormData(form[0]);

	alert( formData.get('formID'));

}

document.addEventListener('DOMContentLoaded', function(){

	submitInput.addEventListener('click', getDataform, false);

}, false);

